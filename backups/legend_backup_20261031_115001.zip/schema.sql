-- LEGEND D ERP: بنية القاعدة (مولَّدة آلياً بالانعكاس)

CREATE TABLE accounts (
	code VARCHAR(20) NOT NULL, 
	name_ar VARCHAR(200) NOT NULL, 
	name_en VARCHAR(200), 
	account_type VARCHAR(20) NOT NULL, 
	nature VARCHAR(10) DEFAULT 'مدين'::character varying, 
	parent_code VARCHAR(20), 
	opening_balance NUMERIC(18, 2) DEFAULT 0, 
	is_active BOOLEAN DEFAULT true, 
	created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT now(), 
	is_system BOOLEAN DEFAULT false NOT NULL, 
	CONSTRAINT accounts_pkey PRIMARY KEY (code), 
	CONSTRAINT accounts_parent_code_fkey FOREIGN KEY(parent_code) REFERENCES accounts (code)
);

CREATE TABLE audit_log (
	id SERIAL NOT NULL, 
	entity_type VARCHAR(40) NOT NULL, 
	entity_id VARCHAR(40) NOT NULL, 
	action VARCHAR(40) NOT NULL, 
	actor VARCHAR(120), 
	details TEXT, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	CONSTRAINT audit_log_pkey PRIMARY KEY (id)
);
CREATE INDEX IF NOT EXISTS idx_audit_log_entity ON audit_log (entity_type, entity_id, created_at);

CREATE TABLE branches (
	id SERIAL NOT NULL, 
	code VARCHAR(20) NOT NULL, 
	name_ar TEXT NOT NULL, 
	name_en TEXT, 
	is_active BOOLEAN DEFAULT true, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	CONSTRAINT branches_pkey PRIMARY KEY (id), 
	CONSTRAINT branches_code_key UNIQUE NULLS DISTINCT (code)
);

CREATE TABLE brands (
	code VARCHAR(30) NOT NULL, 
	name_ar VARCHAR(200) NOT NULL, 
	name_en VARCHAR(200), 
	is_active BOOLEAN DEFAULT true NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	CONSTRAINT brands_pkey PRIMARY KEY (code)
);

CREATE TABLE categories (
	code VARCHAR(30) NOT NULL, 
	name_ar VARCHAR(200) NOT NULL, 
	name_en VARCHAR(200), 
	parent_code VARCHAR(30), 
	description TEXT, 
	image_url VARCHAR(300), 
	is_active BOOLEAN DEFAULT true NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	CONSTRAINT categories_pkey PRIMARY KEY (code), 
	CONSTRAINT categories_parent_code_fkey FOREIGN KEY(parent_code) REFERENCES categories (code)
);

CREATE TABLE cost_centers (
	code VARCHAR(20) NOT NULL, 
	name_ar VARCHAR(200) NOT NULL, 
	name_en VARCHAR(200), 
	is_active BOOLEAN DEFAULT true NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	parent_code VARCHAR(20), 
	cc_type VARCHAR(20) DEFAULT 'cost'::character varying NOT NULL, 
	manager_name VARCHAR(150), 
	budget_amount NUMERIC(18, 2) DEFAULT 0 NOT NULL, 
	notes TEXT, 
	updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	CONSTRAINT cost_centers_pkey PRIMARY KEY (code), 
	CONSTRAINT cost_centers_parent_code_fkey FOREIGN KEY(parent_code) REFERENCES cost_centers (code), 
	CONSTRAINT ck_cost_center_type CHECK (cc_type::text = ANY (ARRAY['cost'::character varying, 'profit'::character varying]::text[]))
);
CREATE INDEX IF NOT EXISTS idx_cost_centers_parent ON cost_centers (parent_code);

CREATE TABLE price_lists (
	code VARCHAR(30) NOT NULL, 
	name VARCHAR(200) NOT NULL, 
	is_active BOOLEAN DEFAULT true NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	CONSTRAINT price_lists_pkey PRIMARY KEY (code)
);

CREATE TABLE roles (
	id SERIAL NOT NULL, 
	code VARCHAR(40) NOT NULL, 
	name_ar VARCHAR(120) NOT NULL, 
	name_en VARCHAR(120), 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	description TEXT, 
	permissions JSONB DEFAULT '{}'::jsonb NOT NULL, 
	is_system BOOLEAN DEFAULT false NOT NULL, 
	is_active BOOLEAN DEFAULT true NOT NULL, 
	CONSTRAINT roles_pkey PRIMARY KEY (id), 
	CONSTRAINT roles_code_key UNIQUE NULLS DISTINCT (code)
);

CREATE TABLE schema_migrations (
	version VARCHAR(50) NOT NULL, 
	applied_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	checksum VARCHAR(64), 
	CONSTRAINT schema_migrations_pkey PRIMARY KEY (version)
);

CREATE TABLE unit_templates (
	code VARCHAR(30) NOT NULL, 
	name VARCHAR(200) NOT NULL, 
	base_unit VARCHAR(50) NOT NULL, 
	higher_unit VARCHAR(50), 
	factor NUMERIC(18, 4) DEFAULT 1 NOT NULL, 
	min_price NUMERIC(18, 4), 
	max_price NUMERIC(18, 4), 
	is_active BOOLEAN DEFAULT true NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	CONSTRAINT unit_templates_pkey PRIMARY KEY (code)
);

CREATE TABLE warehouses (
	id SERIAL NOT NULL, 
	code VARCHAR(30) NOT NULL, 
	name VARCHAR(200) NOT NULL, 
	location VARCHAR(200), 
	manager VARCHAR(100), 
	is_active BOOLEAN DEFAULT true, 
	created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT now(), 
	valuation_method VARCHAR(10) DEFAULT 'WAC'::character varying NOT NULL, 
	is_default BOOLEAN DEFAULT false NOT NULL, 
	allow_negative_stock BOOLEAN DEFAULT false NOT NULL, 
	CONSTRAINT warehouses_pkey PRIMARY KEY (id), 
	CONSTRAINT warehouses_code_key UNIQUE NULLS DISTINCT (code), 
	CONSTRAINT warehouses_valuation_method_check CHECK (valuation_method::text = ANY (ARRAY['WAC'::character varying, 'FIFO'::character varying, 'STANDARD'::character varying]::text[]))
);

CREATE TABLE customers (
	code VARCHAR(30) NOT NULL, 
	name VARCHAR(200) NOT NULL, 
	phone VARCHAR(30), 
	email VARCHAR(120), 
	notes TEXT, 
	account_code VARCHAR(20), 
	payment_terms_days INTEGER DEFAULT 0 NOT NULL, 
	is_active BOOLEAN DEFAULT true NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	CONSTRAINT customers_pkey PRIMARY KEY (code), 
	CONSTRAINT customers_account_code_fkey FOREIGN KEY(account_code) REFERENCES accounts (code)
);

CREATE TABLE suppliers (
	code VARCHAR(30) NOT NULL, 
	name VARCHAR(200) NOT NULL, 
	phone VARCHAR(30), 
	email VARCHAR(150), 
	notes TEXT, 
	is_active BOOLEAN DEFAULT true, 
	created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT now(), 
	account_code VARCHAR(20), 
	payment_terms_days INTEGER DEFAULT 0 NOT NULL, 
	CONSTRAINT suppliers_pkey PRIMARY KEY (code), 
	CONSTRAINT suppliers_account_code_fkey FOREIGN KEY(account_code) REFERENCES accounts (code)
);
CREATE INDEX IF NOT EXISTS idx_suppliers_account ON suppliers (account_code);

CREATE TABLE tax_types (
	code VARCHAR(20) NOT NULL, 
	name_ar VARCHAR(100) NOT NULL, 
	name_en VARCHAR(100), 
	rate NUMERIC(5, 2) NOT NULL, 
	is_active BOOLEAN DEFAULT true NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	account_code VARCHAR(20), 
	CONSTRAINT tax_types_pkey PRIMARY KEY (code), 
	CONSTRAINT tax_types_account_code_fkey FOREIGN KEY(account_code) REFERENCES accounts (code)
);
CREATE INDEX IF NOT EXISTS idx_tax_types_account ON tax_types (account_code);

CREATE TABLE users (
	id SERIAL NOT NULL, 
	full_name VARCHAR(200) NOT NULL, 
	email VARCHAR(200) NOT NULL, 
	password_hash VARCHAR(255) NOT NULL, 
	role VARCHAR(50) DEFAULT 'user'::character varying, 
	is_active BOOLEAN DEFAULT true, 
	created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT now(), 
	role_id BIGINT, 
	phone TEXT, 
	last_login_at TIMESTAMP WITHOUT TIME ZONE, 
	updated_at TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP, 
	CONSTRAINT users_pkey PRIMARY KEY (id), 
	CONSTRAINT fk_user_role FOREIGN KEY(role_id) REFERENCES roles (id), 
	CONSTRAINT users_email_key UNIQUE NULLS DISTINCT (email)
);
CREATE INDEX IF NOT EXISTS idx_users_role ON users (role_id);

CREATE TABLE warehouse_locations (
	id SERIAL NOT NULL, 
	warehouse_id INTEGER NOT NULL, 
	name TEXT NOT NULL, 
	rack TEXT, 
	bin TEXT, 
	created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT now(), 
	code TEXT, 
	zone TEXT, 
	barcode VARCHAR(60), 
	picking_sequence INTEGER DEFAULT 0 NOT NULL, 
	max_capacity NUMERIC(18, 4), 
	is_active BOOLEAN DEFAULT true NOT NULL, 
	CONSTRAINT warehouse_locations_pkey PRIMARY KEY (id), 
	CONSTRAINT warehouse_locations_warehouse_id_fkey FOREIGN KEY(warehouse_id) REFERENCES warehouses (id) ON DELETE CASCADE
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_location_barcode ON warehouse_locations (barcode) WHERE (barcode IS NOT NULL);

CREATE TABLE items (
	code VARCHAR(30) NOT NULL, 
	name VARCHAR(200) NOT NULL, 
	unit VARCHAR(20) DEFAULT 'حبة'::character varying, 
	default_cost NUMERIC(18, 4) DEFAULT 0, 
	price NUMERIC(18, 4) DEFAULT 0, 
	qty NUMERIC(18, 4) DEFAULT 0, 
	avg_cost NUMERIC(18, 4) DEFAULT 0, 
	reorder_level NUMERIC(18, 4) DEFAULT 0, 
	is_active BOOLEAN DEFAULT true, 
	created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT now(), 
	id SERIAL NOT NULL, 
	lead_time_days INTEGER DEFAULT 7 NOT NULL, 
	safety_stock_days INTEGER DEFAULT 3 NOT NULL, 
	valuation_method VARCHAR(10), 
	standard_cost NUMERIC(18, 4), 
	tracking_mode VARCHAR(10) DEFAULT 'NONE'::character varying NOT NULL, 
	shelf_life_days INTEGER, 
	name_en VARCHAR(200), 
	description TEXT, 
	barcode VARCHAR(80), 
	category_code VARCHAR(30), 
	brand_code VARCHAR(30), 
	supplier_code VARCHAR(30), 
	supplier_item_code VARCHAR(80), 
	status VARCHAR(20) DEFAULT 'active'::character varying NOT NULL, 
	default_warehouse_id INTEGER, 
	default_location_id INTEGER, 
	CONSTRAINT items_pkey PRIMARY KEY (id), 
	CONSTRAINT items_brand_code_fkey FOREIGN KEY(brand_code) REFERENCES brands (code), 
	CONSTRAINT items_category_code_fkey FOREIGN KEY(category_code) REFERENCES categories (code), 
	CONSTRAINT items_default_location_id_fkey FOREIGN KEY(default_location_id) REFERENCES warehouse_locations (id), 
	CONSTRAINT items_default_warehouse_id_fkey FOREIGN KEY(default_warehouse_id) REFERENCES warehouses (id), 
	CONSTRAINT items_supplier_code_fkey FOREIGN KEY(supplier_code) REFERENCES suppliers (code), 
	CONSTRAINT items_code_unique UNIQUE NULLS DISTINCT (code), 
	CONSTRAINT items_tracking_mode_check CHECK (tracking_mode::text = ANY (ARRAY['NONE'::character varying, 'BATCH'::character varying, 'SERIAL'::character varying]::text[])), 
	CONSTRAINT items_valuation_method_check CHECK (valuation_method::text = ANY (ARRAY['WAC'::character varying, 'FIFO'::character varying, 'STANDARD'::character varying]::text[]))
);
CREATE INDEX IF NOT EXISTS idx_items_barcode ON items (barcode);
CREATE INDEX IF NOT EXISTS idx_items_brand ON items (brand_code);
CREATE INDEX IF NOT EXISTS idx_items_category ON items (category_code);

CREATE TABLE journal_entries (
	id SERIAL NOT NULL, 
	entry_date DATE NOT NULL, 
	debit_account VARCHAR(20), 
	credit_account VARCHAR(20), 
	amount NUMERIC(18, 2), 
	description TEXT, 
	source_type VARCHAR(30) DEFAULT 'manual'::character varying, 
	source_ref VARCHAR(30), 
	created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT now(), 
	created_by_name VARCHAR(100), 
	status VARCHAR(20) DEFAULT 'posted'::character varying NOT NULL, 
	cost_center_code VARCHAR(20), 
	total_amount NUMERIC(18, 2) DEFAULT 0 NOT NULL, 
	branch_id INTEGER, 
	invoice_number VARCHAR(50), 
	supplier_code VARCHAR(30), 
	CONSTRAINT journal_entries_pkey PRIMARY KEY (id), 
	CONSTRAINT journal_entries_branch_id_fkey FOREIGN KEY(branch_id) REFERENCES branches (id), 
	CONSTRAINT journal_entries_cost_center_code_fkey FOREIGN KEY(cost_center_code) REFERENCES cost_centers (code), 
	CONSTRAINT journal_entries_credit_account_fkey FOREIGN KEY(credit_account) REFERENCES accounts (code), 
	CONSTRAINT journal_entries_debit_account_fkey FOREIGN KEY(debit_account) REFERENCES accounts (code), 
	CONSTRAINT journal_entries_supplier_code_fkey FOREIGN KEY(supplier_code) REFERENCES suppliers (code), 
	CONSTRAINT chk_journal_status CHECK (status::text = ANY (ARRAY['posted'::character varying, 'cancelled'::character varying]::text[]))
);
CREATE INDEX IF NOT EXISTS idx_journal_amount ON journal_entries (amount);
CREATE INDEX IF NOT EXISTS idx_journal_branch ON journal_entries (branch_id);
CREATE INDEX IF NOT EXISTS idx_journal_cost_center ON journal_entries (cost_center_code);
CREATE INDEX IF NOT EXISTS idx_journal_created_at ON journal_entries (created_at);
CREATE INDEX IF NOT EXISTS idx_journal_entry_date ON journal_entries (entry_date);
CREATE INDEX IF NOT EXISTS idx_journal_invoice_number ON journal_entries (invoice_number);
CREATE INDEX IF NOT EXISTS idx_journal_status ON journal_entries (status);
CREATE INDEX IF NOT EXISTS idx_journal_supplier_code ON journal_entries (supplier_code);
CREATE UNIQUE INDEX IF NOT EXISTS uq_journal_supplier_invoice_number ON journal_entries (supplier_code, invoice_number) WHERE ((supplier_code IS NOT NULL) AND (invoice_number IS NOT NULL) AND ((status)::text <> 'cancelled'::text));

CREATE TABLE purchase_orders (
	po_number VARCHAR(30) NOT NULL, 
	po_date DATE NOT NULL, 
	supplier_code VARCHAR(30), 
	status VARCHAR(20) DEFAULT 'draft'::character varying, 
	total NUMERIC(18, 2) DEFAULT 0, 
	created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT now(), 
	CONSTRAINT purchase_orders_pkey PRIMARY KEY (po_number), 
	CONSTRAINT purchase_orders_supplier_code_fkey FOREIGN KEY(supplier_code) REFERENCES suppliers (code)
);

CREATE TABLE sales_orders (
	so_number VARCHAR(30) NOT NULL, 
	so_date DATE NOT NULL, 
	customer_code VARCHAR(30) NOT NULL, 
	status VARCHAR(20) DEFAULT 'open'::character varying NOT NULL, 
	total NUMERIC(18, 2) DEFAULT 0 NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	CONSTRAINT sales_orders_pkey PRIMARY KEY (so_number), 
	CONSTRAINT sales_orders_customer_code_fkey FOREIGN KEY(customer_code) REFERENCES customers (code)
);

CREATE TABLE stock_issue_requests (
	id SERIAL NOT NULL, 
	request_number VARCHAR(30) NOT NULL, 
	warehouse_id INTEGER NOT NULL, 
	request_type VARCHAR(20) DEFAULT 'sales'::character varying NOT NULL, 
	source_type VARCHAR(30), 
	source_ref VARCHAR(60), 
	status VARCHAR(15) DEFAULT 'pending'::character varying NOT NULL, 
	requested_by INTEGER, 
	requested_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	decided_by INTEGER, 
	decided_at TIMESTAMP WITH TIME ZONE, 
	notes TEXT, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	CONSTRAINT stock_issue_requests_pkey PRIMARY KEY (id), 
	CONSTRAINT stock_issue_requests_decided_by_fkey FOREIGN KEY(decided_by) REFERENCES users (id), 
	CONSTRAINT stock_issue_requests_requested_by_fkey FOREIGN KEY(requested_by) REFERENCES users (id), 
	CONSTRAINT stock_issue_requests_warehouse_id_fkey FOREIGN KEY(warehouse_id) REFERENCES warehouses (id), 
	CONSTRAINT stock_issue_requests_request_number_key UNIQUE NULLS DISTINCT (request_number), 
	CONSTRAINT stock_issue_requests_request_type_check CHECK (request_type::text = ANY (ARRAY['sales'::character varying, 'transfer_out'::character varying, 'adjustment'::character varying, 'other'::character varying]::text[])), 
	CONSTRAINT stock_issue_requests_status_check CHECK (status::text = ANY (ARRAY['pending'::character varying, 'approved'::character varying, 'rejected'::character varying, 'cancelled'::character varying]::text[]))
);
CREATE INDEX IF NOT EXISTS idx_sir_status ON stock_issue_requests (status);
CREATE INDEX IF NOT EXISTS idx_sir_wh ON stock_issue_requests (warehouse_id);

CREATE TABLE stock_transfers (
	id SERIAL NOT NULL, 
	transfer_number VARCHAR(30) NOT NULL, 
	from_warehouse_id INTEGER NOT NULL, 
	to_warehouse_id INTEGER NOT NULL, 
	status VARCHAR(20) DEFAULT 'draft'::character varying NOT NULL, 
	requested_by INTEGER, 
	approved_by INTEGER, 
	shipped_at TIMESTAMP WITH TIME ZONE, 
	received_at TIMESTAMP WITH TIME ZONE, 
	notes TEXT, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	CONSTRAINT stock_transfers_pkey PRIMARY KEY (id), 
	CONSTRAINT stock_transfers_approved_by_fkey FOREIGN KEY(approved_by) REFERENCES users (id), 
	CONSTRAINT stock_transfers_from_warehouse_id_fkey FOREIGN KEY(from_warehouse_id) REFERENCES warehouses (id), 
	CONSTRAINT stock_transfers_requested_by_fkey FOREIGN KEY(requested_by) REFERENCES users (id), 
	CONSTRAINT stock_transfers_to_warehouse_id_fkey FOREIGN KEY(to_warehouse_id) REFERENCES warehouses (id), 
	CONSTRAINT stock_transfers_transfer_number_key UNIQUE NULLS DISTINCT (transfer_number), 
	CONSTRAINT stock_transfers_check CHECK (from_warehouse_id <> to_warehouse_id), 
	CONSTRAINT stock_transfers_status_check CHECK (status::text = ANY (ARRAY['draft'::character varying, 'pending_approval'::character varying, 'in_transit'::character varying, 'received'::character varying, 'cancelled'::character varying]::text[]))
);

CREATE TABLE user_warehouse_roles (
	id SERIAL NOT NULL, 
	user_id INTEGER NOT NULL, 
	warehouse_id INTEGER, 
	role_id INTEGER NOT NULL, 
	is_active BOOLEAN DEFAULT true NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	CONSTRAINT user_warehouse_roles_pkey PRIMARY KEY (id), 
	CONSTRAINT user_warehouse_roles_role_id_fkey FOREIGN KEY(role_id) REFERENCES roles (id) ON DELETE RESTRICT, 
	CONSTRAINT user_warehouse_roles_user_id_fkey FOREIGN KEY(user_id) REFERENCES users (id) ON DELETE CASCADE, 
	CONSTRAINT user_warehouse_roles_warehouse_id_fkey FOREIGN KEY(warehouse_id) REFERENCES warehouses (id) ON DELETE CASCADE, 
	CONSTRAINT user_warehouse_roles_user_id_warehouse_id_role_id_key UNIQUE NULLS DISTINCT (user_id, warehouse_id, role_id)
);
CREATE INDEX IF NOT EXISTS idx_uwr_user ON user_warehouse_roles (user_id);
CREATE INDEX IF NOT EXISTS idx_uwr_wh ON user_warehouse_roles (warehouse_id);

CREATE TABLE delivery_notes (
	dn_number VARCHAR(30) NOT NULL, 
	dn_date DATE NOT NULL, 
	customer_code VARCHAR(30) NOT NULL, 
	so_number VARCHAR(30), 
	warehouse_id INTEGER, 
	location_id INTEGER, 
	cogs_total NUMERIC(18, 2) DEFAULT 0 NOT NULL, 
	invoice_status VARCHAR(20) DEFAULT 'not_invoiced'::character varying NOT NULL, 
	journal_entry_id INTEGER, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	CONSTRAINT delivery_notes_pkey PRIMARY KEY (dn_number), 
	CONSTRAINT delivery_notes_customer_code_fkey FOREIGN KEY(customer_code) REFERENCES customers (code), 
	CONSTRAINT delivery_notes_journal_entry_id_fkey FOREIGN KEY(journal_entry_id) REFERENCES journal_entries (id), 
	CONSTRAINT delivery_notes_location_id_fkey FOREIGN KEY(location_id) REFERENCES warehouse_locations (id), 
	CONSTRAINT delivery_notes_so_number_fkey FOREIGN KEY(so_number) REFERENCES sales_orders (so_number), 
	CONSTRAINT delivery_notes_warehouse_id_fkey FOREIGN KEY(warehouse_id) REFERENCES warehouses (id)
);
CREATE INDEX IF NOT EXISTS idx_delivery_notes_customer ON delivery_notes (customer_code);

CREATE TABLE goods_receipts (
	grn_number VARCHAR(30) NOT NULL, 
	grn_date DATE NOT NULL, 
	supplier_code VARCHAR(30), 
	po_number VARCHAR(30), 
	reference VARCHAR(200), 
	total NUMERIC(18, 2) DEFAULT 0, 
	invoice_status VARCHAR(20) DEFAULT 'not_invoiced'::character varying, 
	created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT now(), 
	journal_entry_id INTEGER, 
	warehouse_id INTEGER, 
	location_id INTEGER, 
	CONSTRAINT goods_receipts_pkey PRIMARY KEY (grn_number), 
	CONSTRAINT goods_receipts_journal_entry_id_fkey FOREIGN KEY(journal_entry_id) REFERENCES journal_entries (id), 
	CONSTRAINT goods_receipts_location_id_fkey FOREIGN KEY(location_id) REFERENCES warehouse_locations (id), 
	CONSTRAINT goods_receipts_po_number_fkey FOREIGN KEY(po_number) REFERENCES purchase_orders (po_number), 
	CONSTRAINT goods_receipts_supplier_code_fkey FOREIGN KEY(supplier_code) REFERENCES suppliers (code), 
	CONSTRAINT goods_receipts_warehouse_id_fkey FOREIGN KEY(warehouse_id) REFERENCES warehouses (id)
);
CREATE INDEX IF NOT EXISTS idx_goods_receipts_journal ON goods_receipts (journal_entry_id);
CREATE INDEX IF NOT EXISTS idx_grn_warehouse ON goods_receipts (warehouse_id);

CREATE TABLE item_batches (
	id SERIAL NOT NULL, 
	item_id INTEGER NOT NULL, 
	warehouse_id INTEGER NOT NULL, 
	location_id INTEGER, 
	batch_number VARCHAR(60) NOT NULL, 
	mfg_date DATE, 
	expiry_date DATE, 
	qty_on_hand NUMERIC(18, 4) DEFAULT 0 NOT NULL, 
	unit_cost NUMERIC(18, 4) DEFAULT 0 NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	CONSTRAINT item_batches_pkey PRIMARY KEY (id), 
	CONSTRAINT item_batches_item_id_fkey FOREIGN KEY(item_id) REFERENCES items (id) ON DELETE CASCADE, 
	CONSTRAINT item_batches_location_id_fkey FOREIGN KEY(location_id) REFERENCES warehouse_locations (id) ON DELETE SET NULL, 
	CONSTRAINT item_batches_warehouse_id_fkey FOREIGN KEY(warehouse_id) REFERENCES warehouses (id) ON DELETE CASCADE, 
	CONSTRAINT item_batches_item_id_warehouse_id_batch_number_key UNIQUE NULLS DISTINCT (item_id, warehouse_id, batch_number)
);
CREATE INDEX IF NOT EXISTS idx_batches_expiry ON item_batches (expiry_date);
CREATE INDEX IF NOT EXISTS idx_batches_item ON item_batches (item_id);

CREATE TABLE item_cost_layers (
	id SERIAL NOT NULL, 
	item_id INTEGER NOT NULL, 
	warehouse_id INTEGER NOT NULL, 
	receipt_date DATE NOT NULL, 
	qty_remaining NUMERIC(18, 4) NOT NULL, 
	unit_cost NUMERIC(18, 4) NOT NULL, 
	source_type VARCHAR(30), 
	source_ref VARCHAR(60), 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	CONSTRAINT item_cost_layers_pkey PRIMARY KEY (id), 
	CONSTRAINT item_cost_layers_item_id_fkey FOREIGN KEY(item_id) REFERENCES items (id) ON DELETE CASCADE, 
	CONSTRAINT item_cost_layers_warehouse_id_fkey FOREIGN KEY(warehouse_id) REFERENCES warehouses (id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_layers_item_wh ON item_cost_layers (item_id, warehouse_id, receipt_date);

CREATE TABLE journal_entry_attachments (
	id SERIAL NOT NULL, 
	entry_id INTEGER NOT NULL, 
	file_name VARCHAR(255) NOT NULL, 
	file_url TEXT NOT NULL, 
	file_type VARCHAR(100), 
	file_size INTEGER, 
	uploaded_by VARCHAR(100), 
	uploaded_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	CONSTRAINT journal_entry_attachments_pkey PRIMARY KEY (id), 
	CONSTRAINT journal_entry_attachments_entry_id_fkey FOREIGN KEY(entry_id) REFERENCES journal_entries (id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_journal_attachments_entry ON journal_entry_attachments (entry_id);

CREATE TABLE journal_entry_lines (
	id SERIAL NOT NULL, 
	entry_id INTEGER NOT NULL, 
	account_code VARCHAR(20) NOT NULL, 
	debit NUMERIC(18, 2) DEFAULT 0 NOT NULL, 
	credit NUMERIC(18, 2) DEFAULT 0 NOT NULL, 
	description TEXT, 
	line_no INTEGER, 
	line_description TEXT, 
	tax_type_code VARCHAR(20), 
	tax_rate NUMERIC(5, 2), 
	tax_amount NUMERIC(18, 2), 
	CONSTRAINT journal_entry_lines_pkey PRIMARY KEY (id), 
	CONSTRAINT journal_entry_lines_entry_id_fkey FOREIGN KEY(entry_id) REFERENCES journal_entries (id) ON DELETE CASCADE, 
	CONSTRAINT journal_entry_lines_tax_type_code_fkey FOREIGN KEY(tax_type_code) REFERENCES tax_types (code)
);
CREATE INDEX IF NOT EXISTS idx_lines_account ON journal_entry_lines (account_code);
CREATE INDEX IF NOT EXISTS idx_lines_entry ON journal_entry_lines (entry_id);

CREATE TABLE price_list_items (
	id SERIAL NOT NULL, 
	price_list_code VARCHAR(30) NOT NULL, 
	item_id INTEGER NOT NULL, 
	price NUMERIC(18, 4) DEFAULT 0 NOT NULL, 
	CONSTRAINT price_list_items_pkey PRIMARY KEY (id), 
	CONSTRAINT price_list_items_item_id_fkey FOREIGN KEY(item_id) REFERENCES items (id) ON DELETE CASCADE, 
	CONSTRAINT price_list_items_price_list_code_fkey FOREIGN KEY(price_list_code) REFERENCES price_lists (code) ON DELETE CASCADE, 
	CONSTRAINT price_list_items_price_list_code_item_id_key UNIQUE NULLS DISTINCT (price_list_code, item_id)
);
CREATE INDEX IF NOT EXISTS idx_price_list_items_item ON price_list_items (item_id);
CREATE INDEX IF NOT EXISTS idx_price_list_items_list ON price_list_items (price_list_code);

CREATE TABLE purchase_order_lines (
	id SERIAL NOT NULL, 
	po_number VARCHAR(30), 
	item_code VARCHAR(30), 
	qty NUMERIC(18, 4) NOT NULL, 
	unit_price NUMERIC(18, 4) NOT NULL, 
	item_id INTEGER, 
	CONSTRAINT purchase_order_lines_pkey PRIMARY KEY (id), 
	CONSTRAINT purchase_order_lines_item_id_fkey FOREIGN KEY(item_id) REFERENCES items (id), 
	CONSTRAINT purchase_order_lines_po_number_fkey FOREIGN KEY(po_number) REFERENCES purchase_orders (po_number) ON DELETE CASCADE
);

CREATE TABLE sales_order_lines (
	id SERIAL NOT NULL, 
	so_number VARCHAR(30) NOT NULL, 
	item_id INTEGER NOT NULL, 
	qty NUMERIC(18, 4) NOT NULL, 
	unit_price NUMERIC(18, 4) NOT NULL, 
	CONSTRAINT sales_order_lines_pkey PRIMARY KEY (id), 
	CONSTRAINT sales_order_lines_item_id_fkey FOREIGN KEY(item_id) REFERENCES items (id), 
	CONSTRAINT sales_order_lines_so_number_fkey FOREIGN KEY(so_number) REFERENCES sales_orders (so_number) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_sales_order_lines_so ON sales_order_lines (so_number);

CREATE TABLE sales_quotes (
	quote_number VARCHAR(30) NOT NULL, 
	quote_date DATE NOT NULL, 
	customer_code VARCHAR(30) NOT NULL, 
	valid_until DATE, 
	status VARCHAR(20) DEFAULT 'draft'::character varying NOT NULL, 
	total NUMERIC(18, 2) DEFAULT 0 NOT NULL, 
	so_number VARCHAR(30), 
	notes TEXT, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	CONSTRAINT sales_quotes_pkey PRIMARY KEY (quote_number), 
	CONSTRAINT sales_quotes_customer_code_fkey FOREIGN KEY(customer_code) REFERENCES customers (code), 
	CONSTRAINT sales_quotes_so_number_fkey FOREIGN KEY(so_number) REFERENCES sales_orders (so_number)
);
CREATE INDEX IF NOT EXISTS idx_sales_quotes_customer ON sales_quotes (customer_code);

CREATE TABLE stock_moves (
	id SERIAL NOT NULL, 
	move_date DATE NOT NULL, 
	item_code VARCHAR(30), 
	move_type VARCHAR(30) NOT NULL, 
	reference VARCHAR(200), 
	qty NUMERIC(18, 4) NOT NULL, 
	unit_cost NUMERIC(18, 4) DEFAULT 0, 
	balance_after NUMERIC(18, 4) NOT NULL, 
	created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT now(), 
	item_id INTEGER, 
	warehouse_id INTEGER, 
	CONSTRAINT stock_moves_pkey PRIMARY KEY (id), 
	CONSTRAINT stock_moves_item_id_fkey FOREIGN KEY(item_id) REFERENCES items (id), 
	CONSTRAINT stock_moves_warehouse_id_fkey FOREIGN KEY(warehouse_id) REFERENCES warehouses (id)
);
CREATE INDEX IF NOT EXISTS idx_stock_moves_warehouse ON stock_moves (warehouse_id);

CREATE TABLE supplier_payments (
	payment_number VARCHAR(30) NOT NULL, 
	payment_date DATE NOT NULL, 
	supplier_code VARCHAR(30) NOT NULL, 
	payment_method VARCHAR(20) DEFAULT 'bank_transfer'::character varying NOT NULL, 
	account_code VARCHAR(20) NOT NULL, 
	reference VARCHAR(120), 
	notes TEXT, 
	amount NUMERIC(18, 2) DEFAULT 0 NOT NULL, 
	status VARCHAR(20) DEFAULT 'posted'::character varying NOT NULL, 
	journal_entry_id INTEGER, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	CONSTRAINT supplier_payments_pkey PRIMARY KEY (payment_number), 
	CONSTRAINT supplier_payments_account_code_fkey FOREIGN KEY(account_code) REFERENCES accounts (code), 
	CONSTRAINT supplier_payments_journal_entry_id_fkey FOREIGN KEY(journal_entry_id) REFERENCES journal_entries (id), 
	CONSTRAINT supplier_payments_supplier_code_fkey FOREIGN KEY(supplier_code) REFERENCES suppliers (code)
);
CREATE INDEX IF NOT EXISTS idx_supplier_payments_supplier ON supplier_payments (supplier_code);

CREATE TABLE warehouse_stock (
	id SERIAL NOT NULL, 
	warehouse_id INTEGER NOT NULL, 
	location_id INTEGER, 
	item_id INTEGER NOT NULL, 
	quantity NUMERIC(18, 4) DEFAULT 0 NOT NULL, 
	avg_cost NUMERIC(18, 4) DEFAULT 0 NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	CONSTRAINT warehouse_stock_pkey PRIMARY KEY (id), 
	CONSTRAINT warehouse_stock_item_id_fkey FOREIGN KEY(item_id) REFERENCES items (id) ON DELETE CASCADE, 
	CONSTRAINT warehouse_stock_location_id_fkey FOREIGN KEY(location_id) REFERENCES warehouse_locations (id) ON DELETE SET NULL, 
	CONSTRAINT warehouse_stock_warehouse_id_fkey FOREIGN KEY(warehouse_id) REFERENCES warehouses (id) ON DELETE CASCADE, 
	CONSTRAINT warehouse_stock_warehouse_id_location_id_item_id_key UNIQUE NULLS DISTINCT (warehouse_id, location_id, item_id)
);
CREATE INDEX IF NOT EXISTS idx_wstock_item ON warehouse_stock (item_id);
CREATE INDEX IF NOT EXISTS idx_wstock_wh ON warehouse_stock (warehouse_id);

CREATE TABLE delivery_note_lines (
	id SERIAL NOT NULL, 
	dn_number VARCHAR(30) NOT NULL, 
	item_id INTEGER NOT NULL, 
	qty NUMERIC(18, 4) NOT NULL, 
	unit_cost NUMERIC(18, 4) DEFAULT 0 NOT NULL, 
	unit_price NUMERIC(18, 4) DEFAULT 0 NOT NULL, 
	CONSTRAINT delivery_note_lines_pkey PRIMARY KEY (id), 
	CONSTRAINT delivery_note_lines_dn_number_fkey FOREIGN KEY(dn_number) REFERENCES delivery_notes (dn_number) ON DELETE CASCADE, 
	CONSTRAINT delivery_note_lines_item_id_fkey FOREIGN KEY(item_id) REFERENCES items (id)
);
CREATE INDEX IF NOT EXISTS idx_delivery_note_lines_dn ON delivery_note_lines (dn_number);

CREATE TABLE goods_receipt_lines (
	id SERIAL NOT NULL, 
	grn_number VARCHAR(30), 
	item_code VARCHAR(30), 
	qty NUMERIC(18, 4) NOT NULL, 
	unit_cost NUMERIC(18, 4) NOT NULL, 
	item_id INTEGER, 
	CONSTRAINT goods_receipt_lines_pkey PRIMARY KEY (id), 
	CONSTRAINT goods_receipt_lines_grn_number_fkey FOREIGN KEY(grn_number) REFERENCES goods_receipts (grn_number) ON DELETE CASCADE, 
	CONSTRAINT goods_receipt_lines_item_id_fkey FOREIGN KEY(item_id) REFERENCES items (id)
);

CREATE TABLE item_serials (
	id SERIAL NOT NULL, 
	item_id INTEGER NOT NULL, 
	warehouse_id INTEGER NOT NULL, 
	location_id INTEGER, 
	batch_id INTEGER, 
	serial_number VARCHAR(80) NOT NULL, 
	status VARCHAR(15) DEFAULT 'in_stock'::character varying NOT NULL, 
	unit_cost NUMERIC(18, 4) DEFAULT 0 NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	CONSTRAINT item_serials_pkey PRIMARY KEY (id), 
	CONSTRAINT item_serials_batch_id_fkey FOREIGN KEY(batch_id) REFERENCES item_batches (id) ON DELETE SET NULL, 
	CONSTRAINT item_serials_item_id_fkey FOREIGN KEY(item_id) REFERENCES items (id) ON DELETE CASCADE, 
	CONSTRAINT item_serials_location_id_fkey FOREIGN KEY(location_id) REFERENCES warehouse_locations (id) ON DELETE SET NULL, 
	CONSTRAINT item_serials_warehouse_id_fkey FOREIGN KEY(warehouse_id) REFERENCES warehouses (id) ON DELETE CASCADE, 
	CONSTRAINT item_serials_serial_number_key UNIQUE NULLS DISTINCT (serial_number), 
	CONSTRAINT item_serials_status_check CHECK (status::text = ANY (ARRAY['in_stock'::character varying, 'reserved'::character varying, 'issued'::character varying, 'sold'::character varying, 'returned'::character varying, 'scrapped'::character varying]::text[]))
);
CREATE INDEX IF NOT EXISTS idx_serials_item ON item_serials (item_id);
CREATE INDEX IF NOT EXISTS idx_serials_status ON item_serials (status);

CREATE TABLE line_cost_allocations (
	id SERIAL NOT NULL, 
	line_id INTEGER NOT NULL, 
	cost_center_code VARCHAR(20) NOT NULL, 
	percentage NUMERIC(5, 2) NOT NULL, 
	CONSTRAINT line_cost_allocations_pkey PRIMARY KEY (id), 
	CONSTRAINT line_cost_allocations_cost_center_code_fkey FOREIGN KEY(cost_center_code) REFERENCES cost_centers (code), 
	CONSTRAINT line_cost_allocations_line_id_fkey FOREIGN KEY(line_id) REFERENCES journal_entry_lines (id) ON DELETE CASCADE, 
	CONSTRAINT ck_lca_percentage CHECK (percentage > 0::numeric AND percentage <= 100::numeric)
);
CREATE INDEX IF NOT EXISTS idx_lca_line ON line_cost_allocations (line_id);

CREATE TABLE purchase_invoices (
	inv_number VARCHAR(30) NOT NULL, 
	inv_date DATE NOT NULL, 
	supplier_code VARCHAR(30), 
	grn_number VARCHAR(30), 
	supplier_inv_number VARCHAR(60), 
	total NUMERIC(18, 2) DEFAULT 0, 
	status VARCHAR(20) DEFAULT 'posted'::character varying, 
	created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT now(), 
	payment_terms_days INTEGER DEFAULT 0 NOT NULL, 
	cost_center_code VARCHAR(20), 
	subtotal NUMERIC(18, 2) DEFAULT 0 NOT NULL, 
	tax_type_code VARCHAR(20), 
	tax_amount NUMERIC(18, 2) DEFAULT 0 NOT NULL, 
	journal_entry_id INTEGER, 
	notes TEXT, 
	CONSTRAINT purchase_invoices_pkey PRIMARY KEY (inv_number), 
	CONSTRAINT purchase_invoices_cost_center_code_fkey FOREIGN KEY(cost_center_code) REFERENCES cost_centers (code), 
	CONSTRAINT purchase_invoices_grn_number_fkey FOREIGN KEY(grn_number) REFERENCES goods_receipts (grn_number), 
	CONSTRAINT purchase_invoices_journal_entry_id_fkey FOREIGN KEY(journal_entry_id) REFERENCES journal_entries (id), 
	CONSTRAINT purchase_invoices_supplier_code_fkey FOREIGN KEY(supplier_code) REFERENCES suppliers (code), 
	CONSTRAINT purchase_invoices_tax_type_code_fkey FOREIGN KEY(tax_type_code) REFERENCES tax_types (code)
);
CREATE INDEX IF NOT EXISTS idx_purchase_invoices_cost_center ON purchase_invoices (cost_center_code);
CREATE INDEX IF NOT EXISTS idx_purchase_invoices_journal ON purchase_invoices (journal_entry_id);
CREATE INDEX IF NOT EXISTS idx_purchase_invoices_tax_type ON purchase_invoices (tax_type_code);

CREATE TABLE sales_invoices (
	inv_number VARCHAR(30) NOT NULL, 
	inv_date DATE NOT NULL, 
	customer_code VARCHAR(30) NOT NULL, 
	customer_ref_number VARCHAR(60), 
	warehouse_id INTEGER, 
	location_id INTEGER, 
	subtotal NUMERIC(18, 2) DEFAULT 0 NOT NULL, 
	tax_type_code VARCHAR(20), 
	tax_amount NUMERIC(18, 2) DEFAULT 0 NOT NULL, 
	total NUMERIC(18, 2) DEFAULT 0 NOT NULL, 
	cogs_total NUMERIC(18, 2) DEFAULT 0 NOT NULL, 
	payment_terms_days INTEGER DEFAULT 0 NOT NULL, 
	cost_center_code VARCHAR(20), 
	status VARCHAR(20) DEFAULT 'posted'::character varying NOT NULL, 
	journal_entry_id INTEGER, 
	notes TEXT, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	delivery_number VARCHAR(30), 
	so_number VARCHAR(30), 
	CONSTRAINT sales_invoices_pkey PRIMARY KEY (inv_number), 
	CONSTRAINT sales_invoices_cost_center_code_fkey FOREIGN KEY(cost_center_code) REFERENCES cost_centers (code), 
	CONSTRAINT sales_invoices_customer_code_fkey FOREIGN KEY(customer_code) REFERENCES customers (code), 
	CONSTRAINT sales_invoices_delivery_number_fkey FOREIGN KEY(delivery_number) REFERENCES delivery_notes (dn_number), 
	CONSTRAINT sales_invoices_journal_entry_id_fkey FOREIGN KEY(journal_entry_id) REFERENCES journal_entries (id), 
	CONSTRAINT sales_invoices_location_id_fkey FOREIGN KEY(location_id) REFERENCES warehouse_locations (id), 
	CONSTRAINT sales_invoices_so_number_fkey FOREIGN KEY(so_number) REFERENCES sales_orders (so_number), 
	CONSTRAINT sales_invoices_tax_type_code_fkey FOREIGN KEY(tax_type_code) REFERENCES tax_types (code), 
	CONSTRAINT sales_invoices_warehouse_id_fkey FOREIGN KEY(warehouse_id) REFERENCES warehouses (id)
);
CREATE INDEX IF NOT EXISTS idx_sales_invoices_customer ON sales_invoices (customer_code);

CREATE TABLE sales_quote_lines (
	id SERIAL NOT NULL, 
	quote_number VARCHAR(30) NOT NULL, 
	item_id INTEGER NOT NULL, 
	qty NUMERIC(18, 4) NOT NULL, 
	unit_price NUMERIC(18, 4) NOT NULL, 
	CONSTRAINT sales_quote_lines_pkey PRIMARY KEY (id), 
	CONSTRAINT sales_quote_lines_item_id_fkey FOREIGN KEY(item_id) REFERENCES items (id), 
	CONSTRAINT sales_quote_lines_quote_number_fkey FOREIGN KEY(quote_number) REFERENCES sales_quotes (quote_number) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_sales_quote_lines_quote ON sales_quote_lines (quote_number);

CREATE TABLE purchase_invoice_lines (
	id SERIAL NOT NULL, 
	inv_number VARCHAR(30), 
	item_code VARCHAR(30), 
	qty NUMERIC(18, 4) NOT NULL, 
	unit_cost NUMERIC(18, 4) NOT NULL, 
	item_id INTEGER, 
	CONSTRAINT purchase_invoice_lines_pkey PRIMARY KEY (id), 
	CONSTRAINT purchase_invoice_lines_inv_number_fkey FOREIGN KEY(inv_number) REFERENCES purchase_invoices (inv_number) ON DELETE CASCADE, 
	CONSTRAINT purchase_invoice_lines_item_id_fkey FOREIGN KEY(item_id) REFERENCES items (id)
);

CREATE TABLE purchase_returns (
	rt_number VARCHAR(30) NOT NULL, 
	rt_date DATE NOT NULL, 
	supplier_code VARCHAR(30), 
	inv_number VARCHAR(30), 
	total NUMERIC(18, 2) DEFAULT 0, 
	created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT now(), 
	subtotal NUMERIC(18, 2) DEFAULT 0 NOT NULL, 
	tax_type_code VARCHAR(20), 
	tax_amount NUMERIC(18, 2) DEFAULT 0 NOT NULL, 
	journal_entry_id INTEGER, 
	status VARCHAR(20) DEFAULT 'posted'::character varying NOT NULL, 
	CONSTRAINT purchase_returns_pkey PRIMARY KEY (rt_number), 
	CONSTRAINT purchase_returns_inv_number_fkey FOREIGN KEY(inv_number) REFERENCES purchase_invoices (inv_number), 
	CONSTRAINT purchase_returns_journal_entry_id_fkey FOREIGN KEY(journal_entry_id) REFERENCES journal_entries (id), 
	CONSTRAINT purchase_returns_supplier_code_fkey FOREIGN KEY(supplier_code) REFERENCES suppliers (code), 
	CONSTRAINT purchase_returns_tax_type_code_fkey FOREIGN KEY(tax_type_code) REFERENCES tax_types (code)
);
CREATE INDEX IF NOT EXISTS idx_purchase_returns_journal ON purchase_returns (journal_entry_id);

CREATE TABLE sales_invoice_lines (
	id SERIAL NOT NULL, 
	inv_number VARCHAR(30) NOT NULL, 
	item_id INTEGER NOT NULL, 
	qty NUMERIC(18, 4) NOT NULL, 
	unit_price NUMERIC(18, 4) NOT NULL, 
	unit_cost NUMERIC(18, 4) DEFAULT 0 NOT NULL, 
	CONSTRAINT sales_invoice_lines_pkey PRIMARY KEY (id), 
	CONSTRAINT sales_invoice_lines_inv_number_fkey FOREIGN KEY(inv_number) REFERENCES sales_invoices (inv_number) ON DELETE CASCADE, 
	CONSTRAINT sales_invoice_lines_item_id_fkey FOREIGN KEY(item_id) REFERENCES items (id)
);
CREATE INDEX IF NOT EXISTS idx_sales_invoice_lines_inv ON sales_invoice_lines (inv_number);

CREATE TABLE sales_returns (
	rt_number VARCHAR(30) NOT NULL, 
	rt_date DATE NOT NULL, 
	customer_code VARCHAR(30) NOT NULL, 
	inv_number VARCHAR(30) NOT NULL, 
	subtotal NUMERIC(18, 2) DEFAULT 0 NOT NULL, 
	tax_type_code VARCHAR(20), 
	tax_amount NUMERIC(18, 2) DEFAULT 0 NOT NULL, 
	total NUMERIC(18, 2) DEFAULT 0 NOT NULL, 
	cogs_total NUMERIC(18, 2) DEFAULT 0 NOT NULL, 
	status VARCHAR(20) DEFAULT 'posted'::character varying NOT NULL, 
	journal_entry_id INTEGER, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	CONSTRAINT sales_returns_pkey PRIMARY KEY (rt_number), 
	CONSTRAINT sales_returns_customer_code_fkey FOREIGN KEY(customer_code) REFERENCES customers (code), 
	CONSTRAINT sales_returns_inv_number_fkey FOREIGN KEY(inv_number) REFERENCES sales_invoices (inv_number), 
	CONSTRAINT sales_returns_journal_entry_id_fkey FOREIGN KEY(journal_entry_id) REFERENCES journal_entries (id), 
	CONSTRAINT sales_returns_tax_type_code_fkey FOREIGN KEY(tax_type_code) REFERENCES tax_types (code)
);
CREATE INDEX IF NOT EXISTS idx_sales_returns_customer ON sales_returns (customer_code);
CREATE INDEX IF NOT EXISTS idx_sales_returns_invoice ON sales_returns (inv_number);

CREATE TABLE stock_issue_request_lines (
	id SERIAL NOT NULL, 
	request_id INTEGER NOT NULL, 
	item_id INTEGER NOT NULL, 
	qty_requested NUMERIC(18, 4) NOT NULL, 
	batch_id INTEGER, 
	serial_id INTEGER, 
	unit_cost_snapshot NUMERIC(18, 4), 
	CONSTRAINT stock_issue_request_lines_pkey PRIMARY KEY (id), 
	CONSTRAINT stock_issue_request_lines_batch_id_fkey FOREIGN KEY(batch_id) REFERENCES item_batches (id), 
	CONSTRAINT stock_issue_request_lines_item_id_fkey FOREIGN KEY(item_id) REFERENCES items (id), 
	CONSTRAINT stock_issue_request_lines_request_id_fkey FOREIGN KEY(request_id) REFERENCES stock_issue_requests (id) ON DELETE CASCADE, 
	CONSTRAINT stock_issue_request_lines_serial_id_fkey FOREIGN KEY(serial_id) REFERENCES item_serials (id), 
	CONSTRAINT stock_issue_request_lines_qty_requested_check CHECK (qty_requested > 0::numeric)
);
CREATE INDEX IF NOT EXISTS idx_sirl_request ON stock_issue_request_lines (request_id);

CREATE TABLE stock_transfer_lines (
	id SERIAL NOT NULL, 
	transfer_id INTEGER NOT NULL, 
	item_id INTEGER NOT NULL, 
	qty NUMERIC(18, 4) NOT NULL, 
	batch_id INTEGER, 
	serial_id INTEGER, 
	unit_cost_snapshot NUMERIC(18, 4), 
	CONSTRAINT stock_transfer_lines_pkey PRIMARY KEY (id), 
	CONSTRAINT stock_transfer_lines_batch_id_fkey FOREIGN KEY(batch_id) REFERENCES item_batches (id), 
	CONSTRAINT stock_transfer_lines_item_id_fkey FOREIGN KEY(item_id) REFERENCES items (id), 
	CONSTRAINT stock_transfer_lines_serial_id_fkey FOREIGN KEY(serial_id) REFERENCES item_serials (id), 
	CONSTRAINT stock_transfer_lines_transfer_id_fkey FOREIGN KEY(transfer_id) REFERENCES stock_transfers (id) ON DELETE CASCADE, 
	CONSTRAINT stock_transfer_lines_qty_check CHECK (qty > 0::numeric)
);
CREATE INDEX IF NOT EXISTS idx_stl_transfer ON stock_transfer_lines (transfer_id);

CREATE TABLE supplier_payment_allocations (
	id SERIAL NOT NULL, 
	payment_number VARCHAR(30) NOT NULL, 
	inv_number VARCHAR(30) NOT NULL, 
	amount NUMERIC(18, 2) DEFAULT 0 NOT NULL, 
	CONSTRAINT supplier_payment_allocations_pkey PRIMARY KEY (id), 
	CONSTRAINT supplier_payment_allocations_inv_number_fkey FOREIGN KEY(inv_number) REFERENCES purchase_invoices (inv_number), 
	CONSTRAINT supplier_payment_allocations_payment_number_fkey FOREIGN KEY(payment_number) REFERENCES supplier_payments (payment_number) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_spa_invoice ON supplier_payment_allocations (inv_number);
CREATE INDEX IF NOT EXISTS idx_spa_payment ON supplier_payment_allocations (payment_number);

CREATE TABLE warehouse_stock_moves (
	id SERIAL NOT NULL, 
	move_date TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	warehouse_id INTEGER NOT NULL, 
	location_id INTEGER, 
	item_id INTEGER NOT NULL, 
	batch_id INTEGER, 
	serial_id INTEGER, 
	move_type VARCHAR(30) NOT NULL, 
	qty NUMERIC(18, 4) NOT NULL, 
	unit_cost NUMERIC(18, 4) DEFAULT 0 NOT NULL, 
	balance_after NUMERIC(18, 4) DEFAULT 0 NOT NULL, 
	source_type VARCHAR(30), 
	source_ref VARCHAR(60), 
	created_by INTEGER, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	CONSTRAINT warehouse_stock_moves_pkey PRIMARY KEY (id), 
	CONSTRAINT warehouse_stock_moves_batch_id_fkey FOREIGN KEY(batch_id) REFERENCES item_batches (id), 
	CONSTRAINT warehouse_stock_moves_created_by_fkey FOREIGN KEY(created_by) REFERENCES users (id), 
	CONSTRAINT warehouse_stock_moves_item_id_fkey FOREIGN KEY(item_id) REFERENCES items (id), 
	CONSTRAINT warehouse_stock_moves_location_id_fkey FOREIGN KEY(location_id) REFERENCES warehouse_locations (id), 
	CONSTRAINT warehouse_stock_moves_serial_id_fkey FOREIGN KEY(serial_id) REFERENCES item_serials (id), 
	CONSTRAINT warehouse_stock_moves_warehouse_id_fkey FOREIGN KEY(warehouse_id) REFERENCES warehouses (id)
);
CREATE INDEX IF NOT EXISTS idx_wsm_item_wh ON warehouse_stock_moves (item_id, warehouse_id);
CREATE INDEX IF NOT EXISTS idx_wsm_source ON warehouse_stock_moves (source_type, source_ref);

CREATE TABLE purchase_return_lines (
	id SERIAL NOT NULL, 
	rt_number VARCHAR(30), 
	item_code VARCHAR(30), 
	qty NUMERIC(18, 4) NOT NULL, 
	unit_cost NUMERIC(18, 4) NOT NULL, 
	item_id INTEGER, 
	CONSTRAINT purchase_return_lines_pkey PRIMARY KEY (id), 
	CONSTRAINT purchase_return_lines_item_id_fkey FOREIGN KEY(item_id) REFERENCES items (id), 
	CONSTRAINT purchase_return_lines_rt_number_fkey FOREIGN KEY(rt_number) REFERENCES purchase_returns (rt_number) ON DELETE CASCADE
);

CREATE TABLE sales_return_lines (
	id SERIAL NOT NULL, 
	rt_number VARCHAR(30) NOT NULL, 
	item_id INTEGER NOT NULL, 
	qty NUMERIC(18, 4) NOT NULL, 
	unit_price NUMERIC(18, 4) NOT NULL, 
	unit_cost NUMERIC(18, 4) DEFAULT 0 NOT NULL, 
	CONSTRAINT sales_return_lines_pkey PRIMARY KEY (id), 
	CONSTRAINT sales_return_lines_item_id_fkey FOREIGN KEY(item_id) REFERENCES items (id), 
	CONSTRAINT sales_return_lines_rt_number_fkey FOREIGN KEY(rt_number) REFERENCES sales_returns (rt_number) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_sales_return_lines_rt ON sales_return_lines (rt_number);

